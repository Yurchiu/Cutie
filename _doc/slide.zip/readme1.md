1

下文中，这句话将会被替换为：”`zzy` AK IOI！“

`zzy` AK IOI！

{sep}

</>

<topic>Read me 文件</topic>

<subtopic>第一号文件</subtopic>

</>

# 如何制作 PPT

1. 创建一个 .md 文件，命名为 `ppt.md`。
2. 替换功能：第一行必须是一个数字 $n$；接下来为 $2n$ 行，被替换字符串和所替换为的字符串交替出现。如不想使用，单独输入一个 0。
3. 接下来输入 `{sep}` 分割。
4. 之后，就可以写正文了！
5. 分页方式是单独一行 `{sep}`，或者使用 h1 标题 `#`。
6. 完成后，运行 `main.exe` 即可。

这句话展示了替换功能：下文中，这句话将会被替换为：”`zzy` AK IOI！“

# 如何演示 PPT

用浏览器打开生成的 `ppt.html` 即可。全屏使用效果最佳。

## 翻页

使用键盘的左右箭头即可。

或者使用鼠标左键点击左下或右下。

## 画笔

按键 `Y` 启用画笔，按下鼠标左键即可使用画笔。

- 擦除：刷新浏览器，或按键 `X`。
- 使用或停用：按键 `Y` 或 `N`。

---

更多命令，见 readme2。

# Markdown 支持列表

```markdown
[超链接](https://example.com)
	
- 无序列表
- 无序列表
	
1. 有序列表
2. 有序列表
	
_斜体_
	
**加粗**
	
---
	
![图片](图片链接)
	
> 引用名言
	
# ~ ###### 标题
	
`代码片段`
	
注：行间代码使用三个 `
	
$行内 LaTeX$
	
~~删除线~~
	
$$
行间 LaTeX
$$
```

# 拓展样式

## Part 1

使用方法：`<p class="样式">文字</p>`。如为行内，则把 `p` 替换为 `span`。

**字体大小：**

- `big`：60 px。
- `tiny`：20 px。
- `micro`：极小。

**贴纸 `pos`：**

- 使用 `left: 6%` 或 `left: 6px`  来确定距离左端的距离。`right`，`top`，`bottom` 同理。
- 使用 `width` 确定宽度，`height` 同理。

{sep}

**文字位置：**

- `mid`：居中。
- `right`：居右。

**颜色：**

- 文字：红色，白色，蓝色，黄色，<span class="invsb">不可见</span>。
- 背景：红色，黑色，蓝色，黄色，白色。<span class="red">这是例子。</span>

**$\LaTeX$：**支持行内公式、行间公式。

- 行内公式：$\sum_{i=1}^{n}a_i=114514$。
- 行间公式：

$$
\prod_{i=1}^{n}a_i=1919810
$$

{sep}

**特殊：**

- `red`：<red>高亮强调</red>。
- `blue`：<blue>高亮强调</blue>。
- `yellow`：<yellow>高亮强调</yellow>。
- `invsb`：<invsb>~~不高亮不强调~~</invsb>。

更多拓展样式，请见下一页。

{sep}

## Part 2

这是 PPT 第一页的参考代码：

```html
<topic>Read me 文件</topic>
<subtopic>第一号文件</subtopic>
```

~~用 topic 而不是 title 的原因是，title 是一个 html 标签。~~

<details>
    <summary>这是一个折叠器，请点击</summary>
    <p>然后被折叠的内容会被展示：头滚键盘~~wiudfgahdgvbakweiufhaowieghaorwuaGVObnofenbhoweigfiuQFUVEBDJ~~</p>
</details>

提示：<shady>您太强了</shady>。由于本句话被高度加密，即使使用小刀或者<span class="bg-black">除了被选中</span>也无法划开屏幕上的部分黑幕。<wshady>这是白幕。</wshady><span class="invsb">这是需被选中的白幕。</span>

更多拓展样式，请见 readme2 文件。

# 注意

1. 请使用 ANSI 编码（可以使用电脑自带的记事本更改编码）。
2. 为了获得最好体验，请使用谷歌浏览器。
3. 有序/无序列表不支持嵌套。
4. 要设背景图片/色，或进行魔改，请直接修改源码（`css` 文件夹）。
5. 注意，<red>代码框中不要有空行</red>！否则会运行错误。
6. 链接、图片链接中不能有特殊字符。
7. 内嵌 HTML 代码，请像插入代码一样用 `</>` 包裹。被 `</>` 包裹住的内容，markdown 不可用。
8. 本压缩包附带一个 OI 题课件例子，可供研究。